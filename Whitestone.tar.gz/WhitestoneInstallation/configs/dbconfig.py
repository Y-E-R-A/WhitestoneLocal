pg_config = {


    'user' : 'whitestoneadmin',
    'passwd' : 'capstone',
    'dbname' : 'whitestone'



}
