(function() {

    var app = angular.module('Whitestone',['ngRoute']);

    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider, $location) {
        $routeProvider.when('/login', {
            templateUrl: '/static/pages/login.html',
            controller: 'LoginController',
            controllerAs : 'loginCtrl'
        }).when('/activityLog/:role/:uid', {
            templateUrl: '/static/pages/activityLog.html',
            controller: 'activityLogController',
            controllerAs : 'activityLogCtrl',
            resolve:{check:function($q,authenticationSvc){
                    var user = authenticationSvc.getUser();
                    if(user.role === "Administrator"){
                        
                    }else{
                        console.log("denied")
                        return $q.reject({authenticated:false});
                    }
                }
            }
        }).when('/meeting/:role/:uid', {
            templateUrl: '/static/pages/createMeeting.html',
            controller: 'createMeetingController',
            controllerAs : 'createMeetingCtrl',
            resolve:{check:function($q,authenticationSvc){
                    var user = authenticationSvc.getUser();
                console.log("user in path"+user.role)
                    if(user.role === "Secretary"){
                        console.log("accept")
                        return $q.when(user);
                    }else{
                        console.log("denied")
                        return $q.reject({authenticated: false});
                    }
                }
            }
        }).when('/createUser/:role/:uid', {
            templateUrl: '/static/pages/createUser.html',
            controller: 'createUserController',
            controllerAs : 'createUserCtrl',
            resolve:{check:function($q,authenticationSvc){
                    var user = authenticationSvc.getUser();
                    if(user.role === "Administrator"){
                        
                    }else{
                        console.log("denied")
                        $q.reject({authenticated:false});
                    }
                }
            }
        }).when('/Vote/:role/:uid', {
            templateUrl: '/static/pages/createVote.html',
            controller: 'votingController',
            controllerAs : 'votingCtrl',
            resolve:{check:function($q,authenticationSvc){
                    var user = authenticationSvc.getUser();
                    if(user.role === "Secretary"){
                        
                    }else{
                        console.log("denied")
                        $q.reject({authenticated:false});
                    }
                }
            }
        }).when('/submitVoteSenator/:role/uid', {
            templateUrl: '/static/pages/submitVote.html',
            controller: 'submitVoteSenController',
            controllerAs : 'submitVoteSenCtrl'
        }).when('/votingChancellor/:role/:uid', {
            templateUrl: '/static/pages/submitVoteChan.html',
            controller: 'submitVoteChanController',
            controllerAs : 'submitVoteChanCtrl'
        }).when('/oldMeeting/:role/:uid', {
            templateUrl: '/static/pages/viewOldMeetings.html',
            controller: 'oldMeetingsController',
            controllerAs : 'oldMeetingsCtrl',
            resolve:{check:function($q,authenticationSvc){
                    var user = authenticationSvc.getUser();
                    if(user.role === "Secretary"){
                        
                    }else{
                        console.log("denied")
                        $q.reject({authenticated:false});
                    }
                }
            }
        }).when('/editUser/:role/:uid', {
            templateUrl: '/static/pages/editUser.html',
            controller: 'editUserController',
            controllerAs : 'editUserCtrl',
            resolve:{check:function($q,authenticationSvc){
                    var user = authenticationSvc.getUser();
                    if(user.role === "Administrator"){
                        
                    }else{
                        console.log("denied")
                        $q.reject({authenticated:false});
                    }
                }
            }
        }).when('/Turns/:role/:uid', {
            templateUrl: '/static/pages/senator.html',
            controller: 'senatorController',
            controllerAs : 'senatorCtrl'
        }).when('/ChancellorTurns/:role/:uid', {
            templateUrl: '/static/pages/chancellor.html',
            controller: 'chancellorController',
            controllerAs : 'chancellorCtrl'
        }).when('/voting/:role/:uid', {
            templateUrl: '/static/pages/submitVote.html',
            controller: 'submitVoteController',
            controllerAs : 'submitVoteCtrl'
        }).when('/monitor', {
            templateUrl: '/static/pages/monitor.html',
            controller: 'monitorController',
            controllerAs : 'monitorCtrl'
        }).otherwise({
            redirectTo: '/login'
        });
    }]);
    
     app.factory("authenticationSvc", ["$http","$q","$window",function ($http, $q, $window) {
        this.user;

        this.login = function(email,role){
        console.log("svc email"+email);
        console.log("svc role"+role)
        this.user = {
            "email":email,
            "role":role
        };
        $window.sessionStorage.setItem("user",JSON.stringify(this.user));
        }
    
        this.logoutUser = function(){
            this.user = null;
            $window.sessionStorage.removeItem("user");
        }
    
        this.getUser = function(){
            return this.user;
        }
    
        this.init = function() {
            if ($window.sessionStorage["user"]) {
                console.log("Exists")
                this.user = JSON.parse($window.sessionStorage.getItem("user"));
                console.log("user: "+this.user.role)
            }
        }
        //this.init();
        console.log("factory")
    //init();
        return {
      //login: login
            getUser: this.getUser,
            login: this.login,
            logoutUser: this.logoutUser,
            init: this.init
        };
}]);

app.run(["$rootScope", "$location","authenticationSvc", function ($rootScope, $location,authenticationSvc) {
        authenticationSvc.init();

    $rootScope.$on("$routeChangeSuccess", function (user) {
        console.log(user);
    });
    $rootScope.$on("$routeChangeError", function (event, current, previous, eventObj) {
        console.log("hey change")
        if (eventObj.authenticated === false) {
            $location.url("/login");
        }
    });
}]);    

})();
