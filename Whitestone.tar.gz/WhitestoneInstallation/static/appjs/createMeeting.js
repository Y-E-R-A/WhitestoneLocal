angular.module('Whitestone').controller('createMeetingController', ['$http', '$log', '$scope', '$location', '$routeParams','authenticationSvc','$window',
    function($http, $log, $scope, $location, $routeParams,authenticationSvc,$window) {
        // This variable lets you access this controller
        // from within the callbacks of the $http object

        var thisCtrl = this;
        
        var meeting_name = "";
        
        var meeting_desc = "";
        
        var meeting_status = "";
        
        this.active = false;
        this.meetingId = 0;
        var id = 0;
        
        //this.meetingNVal = false;
        //this.meetingDVal = false;
        this.meeting = [];

        //Form for the meeting 
        this.meetingForm;
        this.showMessage = false;

        //Verifies if the input form is correct
        this.checkCreate = function(){
            if(thisCtrl.meetingForm.$valid){
                thisCtrl.showMessage = false;
                thisCtrl.createMeeting();
            }else{
                thisCtrl.showMessage = true;
            }
        };
        
        //This function resets the input fields
        this.clearForm = function(){
            this.meeting_name = "";
            this.meeting_desc = "";
            thisCtrl.meetingForm.$setPristine();
        };
        
        this.createMeeting = function(){

            var d = new Date();
            var data = {};   
            
            data.mname = this.meeting_name;
            data.mdescription = this.meeting_desc;
            
            data.mdate = d.getDate()+"/"+(d.getMonth()+1)+"/"+d.getFullYear();

            data.mtime = d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
            data.mstatus = "Active";
            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/activemeeting";

            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }

            // Now issue the http request to the rest API
            $http.post(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response: " + JSON.stringify(response.data))
                    // assing the part details to the variable in the controller
                    thisCtrl.active = true;
                    thisCtrl.meetingId = response.data.Meeting.mID;
                    thisCtrl.meeting = response.data.Meeting;
                    thisCtrl.clearForm();
                    //thisCtrl.recordActivity();
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;

                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("No se encontro la informacion solicitada.");
                        console.log("Unexpected attributes in post request")
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };   
        
        this.closeMeeting = function(){


            var data = {};
            data.mID = thisCtrl.meetingId;

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/meetingstatus";

            var config = { headers : 
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.put(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response: " + JSON.stringify(response.data))
                    // assing the part details to the variable in the controller
                    thisCtrl.active = false;
                    thisCtrl.recordActivity("Close");
                    thisCtrl.clearWaitingList();
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;

                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        alert("No se encontro la informacion solicitada.");
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        
        this.clearWaitingList = function(){


            var data = {};

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/emptylist";

            var config = { headers : 
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.post(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response clear List: " + JSON.stringify(response.data))
                    
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;

                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("");
                        console.log("No requests found")
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        
        this.loadActiveMeeting = function(){
            

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/activemeeting";
            //console.log("reqURL: " + reqURL);
            var config = { headers : 
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.get(reqURL).then(
                // Success function
                function (response) {
                    console.log("response: " + JSON.stringify(response.data))
                    // assing the part details to the variable in the controller
                    
                    console.log("response "+response.data);
                    //if(response.data.Meeting[0].mstatus==="Active"){
                    thisCtrl.meeting = response.data.Meeting[0];
                    thisCtrl.active = true;
                    thisCtrl.meetingId = response.data.Meeting[0].mID;
                    //}

                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    console.log("thiscredentialList: " +JSON.stringify(thisCtrl.credentialsList));

                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("There is no active meeting");
                        console.log("There is no active meeting")
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        this.recordActivity = function(action){
            
            var d = new Date();
            
            //Dictionary that will store the data for the database
            var data = {};
            data.urole = $routeParams.role;
            data.uemail = authenticationSvc.getUser().email;
            data.date = d.getDate()+"/"+(d.getMonth()+1)+"/"+d.getFullYear();
            data.time = d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
            if(action==="Create"){
                data.logmessage = "Create Meeting";
            }else if(action==="Close"){
                data.logmessage = "Close Meeting";
            }

            //url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/activitylog";

            var config = { headers : 
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.post(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response record AL: " + JSON.stringify(response.data))

                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;

                    if (status == 0) {
                        alert("No Internet Connection");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("Could not store the activity.");
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        this.loadActiveMeeting();
        this.voteRedirect = function(){
            //console.log("uid: "+$routeParams.uid);
            //console.log("role1: "+$routeParams.role);
            //console.log("role2: "+$routeParams.Secretary);
        
            $location.url('/Vote/'+$routeParams.role+'/'+$routeParams.uid);
        }
         this.oldMeetingRedirect = function(){
            //console.log("role"+$routeParams.role)
            //console.log("uid"+$routeParams.uid)
            $location.url('/oldMeeting/'+$routeParams.role+'/'+$routeParams.uid);
        }
        this.logout= function(){
            authenticationSvc.logoutUser();
            $location.url('/login');
        };
}]);
