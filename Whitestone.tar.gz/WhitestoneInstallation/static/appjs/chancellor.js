angular.module('Whitestone').controller('chancellorController', ['$http', '$log', '$scope', '$location', '$routeParams','authenticationSvc',
    function($http, $log, $scope, $location, $routeParams,authenticationSvc) {
        // This variable lets you access this controller
        // from within the callbacks of the $http object
        var thisCtrl = this;
        
        //Meeting information and status
        this.activeMeeting = false;
        this.meetingId = 0;
        
        //The request list of Senators
        this.requestList = [];
        
        //Return Id value of interval function.
        //This is utilized to cancel the interval once the Senator has spoken
        this.intervalId;
        this.clearedInterval = true;

        //Determines if the chancellor is speaking
        this.recordingAudio = false;
        
        //boolean to determine if a senator is speaking.
        //Also used to allow only one Senator to speak
        this.senatorAllowed = false;
        this.senatorId = 0;

        //button ids. This is for enabling and disabling buttons
        this.startId = document.getElementById("start");
        this.stopId = document.getElementById("stop");
        this.activeId = document.getElementById("active");
        this.speakId = document.getElementById("speakMessage");

        //Variables for the mediastream and mediarecorder
        this.media;
        this.stream;
        this.recorder;
        this.chunks;
 	var audioFileName;
       
        //This function accesses the user microphone
        this.allowMicrophone = function(){
            //constraints
            var d = new Date();
            console.log(d)
            var mediaOptions = {
                audio: {
                    tag: 'audio',
                    type: 'audio/mpeg',
                    ext: '.mp3',
                    gUM: {audio: true}
                }
            };
            thisCtrl.media = mediaOptions.audio;
            //Storing the MediaStream object to access the user's microphone
            navigator.mediaDevices.getUserMedia(thisCtrl.media.gUM).then(
                //Success. There is a connected microphone.
                //
                function(mediaStream){
                    //thisCtrl.enableStart = false;
                    thisCtrl.startId.removeAttribute('disabled');
                    console.log("Stream")
                    thisCtrl.stream = mediaStream;
                    console.log("Streamer"+thisCtrl.stream)
                    thisCtrl.recorder = new MediaRecorder(thisCtrl.stream);
                    console.log("recorder in allow"+thisCtrl.recorder);
                    
                    //This function listens to an event.
                    //The event is triggered when the user stops recording
                    thisCtrl.recorder.ondataavailable = function(e){
                        thisCtrl.chunks.push(e.data);
                        if(thisCtrl.recorder.state == 'inactive'){
                            thisCtrl.sendFile();
                        }
                        
                    };
                    thisCtrl.startRecording();
                    console.log("Got Media Succesfully");
                }
                //
            ).catch(function(err){
                console.log("No media detected")
            });
        };
        //This function starts recording
        this.startRecording = function(){
            console.log("Start")
            this.startId.disabled = true;
            this.speakId.style.display = "inherit";
            this.stopId.removeAttribute('disabled');
            this.stopId.style.display = "inherit";
            thisCtrl.chunks = [];
            thisCtrl.recorder.start();
            thisCtrl.recordingAudio = true;
        };
        
        //This function stops recording
        this.stopRecording = function(){
            console.log("Stop")
            this.stopId.disabled = true;
            this.stopId.style.display = "none";
            this.speakId.style.display = "none";
            this.startId.removeAttribute('disabled');
            thisCtrl.recorder.stop();
            thisCtrl.recordingAudio = false;
        };
        
        //This functions sends the audio file to server
        this.sendFile = function(){
            var blob = new Blob(thisCtrl.chunks, {type: thisCtrl.media.type});
            console.log(blob);
            
            var d = new Date();
            var date = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();
            var time = d.getHours()+"-"+d.getMinutes()+"-"+d.getSeconds();
            var DT = date+"-"+time;
	    audioFileName = "Chancellor-"+DT+".mp3";
            console.log(audioFileName)
            var httpRequest = new XMLHttpRequest();
            httpRequest.open("POST", "https://whitestone.uprm.edu/whitestone/meeting/"+thisCtrl.meetingId+"/upload");
            var FileForm = new FormData();
            
            FileForm.append('file', blob, audioFileName);
            httpRequest.onload =function(ev){
                console.log("Request opened.");
            }
            httpRequest.setRequestHeader("Enctype", "multipart/form-data");
            httpRequest.send(FileForm);
            console.log("response: "+JSON.stringify(httpRequest.response))
	    this.commitFile();
        };
        
	    //Added by Ariel
            this.commitFile = function(){

            var data = {};

            data.mID = thisCtrl.meetingId;

            data.aname = audioFileName;

            data.aaddress = '/static/audio/' + thisCtrl.meetingId + '/' + audioFileName;

            data.atype = 'mp3';

            console.log("data: " + JSON.stringify(data));

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/meeting/"+thisCtrl.meetingId+"/audio";
            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }

            // Now issue the http request to the rest API
            $http.post(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("Data committed to the database: " + JSON.stringify(response.data))
                    alert("The file's data has been committed to the database.")
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;

                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        alert("No se encontro la informacion solicitada.");
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };

        //End of Added by Ariel

        //Testing time events
        this.cancelInterval = function(){
            console.log("cancel Interval");
            clearInterval(this.intervalId);
            thisCtrl.clearedInterval = true;
        };
        this.showTime = function(){
            var d = new Date();
            console.log("Show Time");
            this.time = d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
            console.log(thisCtrl.time);
            document.getElementById("time").innerHTML = this.time;
        };
        
        this.loadActiveMeeting = function(){
            
            //Disabling the buttons to avoid errors
            //this.startId.disabled = true;
            //this.stopId.disabled = true;
            //console.log(this.startId)
            //console.log(this.stopId)

            this.stopId.disabled = true;
            this.stopId.style.display = "none";
            this.speakId.style.display = "none";
            this.activeId.style.display = "none";
            
            console.log(this.startId)
            console.log(this.stopId)
            console.log(this.speakId)
            console.log(this.activeId);

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/activemeeting";
            //console.log("reqURL: " + reqURL);
            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.get(reqURL).then(
                // Success function
                function (response) {
                    console.log("response: " + JSON.stringify(response.data))
                    // assing the part details to the variable in the controller
                    
                    console.log("response "+JSON.stringify(response.data));
                    thisCtrl.meeting = response.data.Meeting[0];

                    //Updating the status of the meeting
                    thisCtrl.activeMeeting = true;
                    thisCtrl.activeId.style.display = "inherit";
                    thisCtrl.meetingId = response.data.Meeting[0].mID;

                    thisCtrl.timedInterval(10000);
                    //thisCtrl.getRequestList();
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        alert("There is no active meeting");
                        this.activeId.style.display = "none";
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        //Function to set Interval for get list of waiting Senators
        this.timedInterval = function(timeoutPeriod){
            //this.intervalId = setInterval("",timeoutPeriod);
             //console.log("Time Start")
            //this.intervalId = setInterval(function(){thisCtrl.showTime()},2000);
             //console.log("interval id: "+this.intervalId);
             
             thisCtrl.intervalId = setInterval(function(){thisCtrl.checkActiveMeeting()},timeoutPeriod);
             console.log("interval id: "+thisCtrl.intervalId);
             thisCtrl.clearedInterval = false;
             //this.intervalId = setInterval(function(){thisCtrl.showTime()},2000);
        };
        
        this.cancelInterval = function(){
            console.log("cancel Interval");
            clearInterval(this.intervalId);
            thisCtrl.clearedInterval = true;
        };

        this.getRequestList = function(){
            
            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/getrequestlist";
            // Now issue the http request to the rest API
            $http.get(reqURL).then(
                // Success function
                function (response) {
                    console.log("response get reqlist: " + JSON.stringify(response.data))
                    for(var i=0;i<response.data.TURN.length;i++){
                        if(response.data.TURN[i].approval!="Deny"){
                            //response.data.TURN.splice(i,1);
                            console.log("Man")
                            thisCtrl.requestList.push(response.data.TURN[i]);
                        }
                        if(response.data.TURN[i].approval==="Accept"){
                            console.log("hey")
                            thisCtrl.senatorAllowed = true;
                            thisCtrl.senatorId = response.data.TURN[i].uID;
                        }
                    }

                    thisCtrl.requestList = response.data.TURN;
                    
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("There is no active meeting");
                        console.log("There are no request in the moment")
                        thisCtrl.requestList = [];
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        
        this.grantTurn = function(uid){
            
            var data ={};
            data.uID = uid;
            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/grantrequest";
            
            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
            // Now issue the http request to the rest API
            $http.put(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response grant request: " + JSON.stringify(response.data))
                    thisCtrl.senatorAllowed = true;
                    thisCtrl.senatorId = uid;

                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("There is no active meeting");
                        console.log("Could not grant request")
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        
        this.denyTurn = function(uid){
            
            // Now create the url with the route to talk with the rest API
            var data = {};
            data.uID = uid;
            var reqURL = "https://whitestone.uprm.edu/whitestone/denyrequest";
            
            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
            // Now issue the http request to the rest API
            $http.put(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response get deny: " + JSON.stringify(response.data))
                    //thisCtrl.requestList = response.data.Turn;
                    for(var i=0;i<thisCtrl.requestList.length;i++){
                        if(thisCtrl.requestList[i].uID==parseInt(uid)){
                            thisCtrl.requestList.splice(i,1);
                            break;
                        }
                    }
                    thisCtrl.senatorAllowed = false;
                    thisCtrl.senatorId = 0;

                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("There is no active meeting");
                        console.log("Cpuld not find request")
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };

        this.checkActiveMeeting = function(){

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/activemeeting";
            //console.log("reqURL: " + reqURL);
            var config = { headers : 
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.get(reqURL).then(
                // Success function
                function (response) {
                    console.log("response check meeting: " + JSON.stringify(response.data))
                    thisCtrl.getRequestList();
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;

                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("There is no active meeting");
                        console.log("There is no active meeting")
                        //Disabling the buttons to avoid errors
                        //this.startId.disabled = true;
                        thisCtrl.stopId.disabled = true;
                        thisCtrl.stopId.style.display = "none";
                        thisCtrl.speakId.style.display = "none";
                        thisCtrl.activeId.style.display = "none";
                        if(thisCtrl.recordingAudio){
                            console.log("I'm recording")
                            thisCtrl.stopRecording();
                        }
                        if(!thisCtrl.clearedInterval){
                            thisCtrl.cancelInterval();
                        }
                        thisCtrl.activeMeeting = false;
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        
        this.loadActiveMeeting();
        this.disable = true;
        this.disablebut = function(){
            if(this.disable){
                this.disable = false;
            }else{
                this.disable = true;
            }
        };
        this.voteRedirect = function(){
            //thisCtrl.cancelInterval();
            if(thisCtrl.recordingAudio){
                console.log("I'm recording")
                thisCtrl.stopRecording();
            }
            if(!thisCtrl.clearedInterval){
                thisCtrl.cancelInterval();
            }
            $location.url('/votingChancellor/'+$routeParams.role+'/'+$routeParams.uid);
        }
        this.logout= function(){
            //thisCtrl.cancelInterval();
            if(thisCtrl.recordingAudio){
                thisCtrl.stopRecording();
            }
            if(!thisCtrl.clearedInterval){
                thisCtrl.cancelInterval();
            }
            $authenticationSvc.logoutUser();
            $location.url('/login');
        };
}]);
