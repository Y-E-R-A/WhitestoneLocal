angular.module('Whitestone').controller('senatorController', ['$http', '$log', '$scope', '$location', '$routeParams', 'authenticationSvc',
    function($http, $log, $scope, $location, $routeParams,authenticationSvc) {
        // This variable lets you access this controller
        // from within the callbacks of the $http object
        var thisCtrl = this;
        
        //Meeting information and status
        this.activeMeeting = false;
        this.meetingId = 0;
        
        //Request status
        this.requestedTurn = false;
        
        
        //Boolean to determine if a Senator can speak
        this.turnApproved = false;
	
	//Senator information
	var firstName;
	var lastName;
        
        //Return Id value of interval function.
        //This is utilized to cancel the interval once the Senator has spoken
        this.intervalId;
        this.clearedInterval = true;
        this.time = "00:00:00";

        //Id of the html elements
        //These are used to hide/show elements when certain events are met
        this.waitingId = document.getElementById("wait");
        this.speakingId = document.getElementById("speaking");   
        this.closeId = document.getElementById("close");
        this.activeId = document.getElementById("active");
        
        //Variables for the mediastream and mediarecorder
        this.media;
        this.stream;
        this.recorder;
        this.chunks;
        var audioFileName;

        this.isRecording = false;
        //This function accesses the user microphone
        this.allowMicrophone = function(){
            //constraints
            var d = new Date();
            console.log(d)
            var mediaOptions = {
                audio: {
                    tag: 'audio',
                    type: 'audio/mpeg',
                    ext: '.mp3',
                    gUM: {audio: true}
                }
            };
            thisCtrl.media = mediaOptions.audio;
            //Storing the MediaStream object to access the user's microphone
            navigator.mediaDevices.getUserMedia(thisCtrl.media.gUM).then(
                //Success. There is a connected microphone.
                //
                function(mediaStream){
                    thisCtrl.requestApproved = true;
                    console.log("Stream")
                    thisCtrl.stream = mediaStream;
                    console.log("Streamer"+thisCtrl.stream)
                    thisCtrl.recorder = new MediaRecorder(thisCtrl.stream);
                    console.log("recorder in allow"+thisCtrl.recorder);
                    
                    //This function listens to an event.
                    //The event is triggered when the user stops recording
                    thisCtrl.recorder.ondataavailable = function(e){
                        thisCtrl.chunks.push(e.data);
                        if(thisCtrl.recorder.state == 'inactive'){
                            thisCtrl.sendFile();
                        }
                        
                    };
                    thisCtrl.startRecording();
                    console.log("Got Media Succesfully");
                }
                //
            ).catch(function(err){
                alert("No media detected");
            });
        };
        //This function starts recording
        this.startRecording = function(){
            console.log("Start")
            thisCtrl.waitingId.style.display = "none";
            thisCtrl.speakingId.style.display = "inherit";
            thisCtrl.chunks = [];
            thisCtrl.recorder.start();
            thisCtrl.isRecording = true;
        };
        
        //This function stops recording
        this.stopRecording = function(){
            console.log("Stop")
            thisCtrl.speakingId.style.display = "none";
            thisCtrl.recorder.stop();
            thisCtrl.isRecording = false;
            //console.log("reqTurn"+thisCtrl.requestedTurn)
            //if(thisCtrl.requestedTurn){
            // thisCtrl.cancelTurn();
            //}
            
        };
        
        //This functions sends the audio file to server
        this.sendFile = function(){
            var blob = new Blob(thisCtrl.chunks, {type: thisCtrl.media.type});
            console.log(blob);
            
            var d = new Date();
            var date = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();
            var time = d.getHours()+"-"+d.getMinutes()+"-"+d.getSeconds();
            var DT = date+"-"+time;
	    audioFileName = firstName+"-"+lastName+"-"+DT+".mp3";
            console.log(DT)
            var httpRequest = new XMLHttpRequest();
            httpRequest.open("POST", "https://whitestone.uprm.edu/whitestone/meeting/"+thisCtrl.meetingId+"/upload");
            //httpRequest.open("POST", "https://whitestone.uprm.edu/uploads");
	        //var fileData = '{"mID":"'+thisCtrl.meetingId + '","aname":"' + audioFileName +  '", "aaddress":' + '"/static/audio/' + thisCtrl.meetingId + '/' + audioFileName + '","atype:mp3"}';
	        //console.log(fileData);
	        //var fileDataJSON = JSON.stringify(fileData);
          
	    var FileForm = new FormData();
            
            FileForm.append('file', blob, audioFileName);
	      //  FileForm.append('data', fileDataJSON);
            httpRequest.onload =function(ev){
                console.log("Request opened.");
            }
            httpRequest.setRequestHeader("Enctype", "multipart/form-data");
            httpRequest.send(FileForm);
            console.log("response: "+JSON.stringify(httpRequest.response))
            this.commitFile();
        };
        
        //Added by Ariel
        this.commitFile = function(){

            var data = {};
        
            data.mID = thisCtrl.meetingId;
            
            data.aname = audioFileName;
            
            data.aaddress = '/static/audio/' + thisCtrl.meetingId + '/' + audioFileName;
            
            data.atype = 'mp3';

            console.log("data: " + JSON.stringify(data));

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/meeting/"+thisCtrl.meetingId+"/audio";
            var config = { headers : 
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.post(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("Data committed to the database: " + JSON.stringify(response.data))
                    alert("The file's data has been committed to the database.")     
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;

                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        alert("No se encontro la informacion solicitada.");
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        }; 

        //End of Added by Ariel


        this.requestTurn = function(){
            
            var data = {};
            data.uID = parseInt($routeParams.uid);

            var reqURL = "https://whitestone.uprm.edu/whitestone/requestTurn";
            //console.log("reqURL: " + reqURL);
            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.post(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response request turn: " + JSON.stringify(response.data))
                    // assing the part details to the variable in the controller
                    thisCtrl.requestedTurn = true;
                    thisCtrl.closeId.style.display = "inherit";
                    thisCtrl.waitingId.style.display = "inherit";
                    thisCtrl.timedInterval(8000);
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        alert("Could not add user to turn list");
                    }
                    else if (status == 400) {
                        alert("Unexpected attributes in post request");
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        //Function to setInterval for Senator request
         this.timedInterval = function(timeoutPeriod){
             
             thisCtrl.intervalId = setInterval(function(){thisCtrl.checkActiveMeeting()},timeoutPeriod);
             console.log("interval id: "+thisCtrl.intervalId);
             thisCtrl.clearedInterval = false;
             //this.intervalId = setInterval(function(){thisCtrl.showTime()},2000);
        };
        
        //Testing time events
        this.cancelInterval = function(){
            console.log("cancel Interval");
            clearInterval(this.intervalId);
            thisCtrl.clearedInterval = true;
        };
        this.showTime = function(){
            var d = new Date();
            console.log("Show Time");
            this.time = d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
            console.log(thisCtrl.time);
            document.getElementById("time").innerHTML = this.time;
        };
        this.cancelTurn = function(){
            
            console.log("Cancel")
            // Now create the url with the route to talk with the rest API
            var data = {};
            data.uID = parseInt($routeParams.uid);
            var reqURL = "https://whitestone.uprm.edu//whitestone/cancelTurn";
            //console.log("reqURL: " + reqURL);
            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.post(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response cancel turn: " + JSON.stringify(response.data))
                    
                    //Stop polling for approval.
                    //clearInterval(thisCtrl.intervalId);
                    thisCtrl.cancelInterval();
                    
                    //Resetting data
                    thisCtrl.requestedTurn = false;
                    //thisCtrl.turnApproved = false;
                    thisCtrl.closeId.style.display = "none";
                    thisCtrl.waitingId.style.display = "none";
                    thisCtrl.speakingId.style.display = "none";

                    thisCtrl.requestApproved = false;
                    if(thisCtrl.isRecording){
                       thisCtrl.stopRecording();
                       }
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        alert("No request found");
                        
                    }else if(status == 400){
                        console.log("Unexpected attributes in post request")
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        
        this.requestApproved = false;
        this.checkApproval = function(){
            // Now create the url with the route to talk with the rest API
            var data = {};
            data.uID = parseInt($routeParams.uid);
            var reqURL = "https://whitestone.uprm.edu/whitestone/checkapproval";
            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.post(reqURL,data,config).then(
                // Success function
                function (response) {
                    console.log("response check approval: " + JSON.stringify(response.data))
                    // assing the part details to the variable in the controller
		                   
		    //Getting the senator's name
                    firstName = response.data.TURN.firstname;
                    lastName = response.data.TURN.lastname;
                    console.log(firstName);
                    console.log(lastName);

                    if(response.data.TURN.approval=="Wait"){
                        console.log("Waiting")
                    }else if(response.data.TURN.approval=="Deny"){
                        console.log("Denied")
                        thisCtrl.cancelTurn();
                    }else if(response.data.TURN.approval=="Accept"){
                        console.log("Approved")
                        if(!thisCtrl.requestApproved){
                            thisCtrl.allowMicrophone();
                            console.log("Allowed")
                            console.log(thisCtrl.requestApproved)
                            //thisCtrl.requestApproved = true;
                    }
                        
                    }
                    //if(!thisCtrl.requestApproved){
                        //thisCtrl.allowMicrophone();
                        //console.log("Allowed")
                        //console.log(thisCtrl.requestApproved)
                        //thisCtrl.requestApproved = true;
                   // }
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if(status == 400){
                        console.log("Unexpected attributes in post request")
                    }
                    else if (status == 404) {
                        //alert("There is no active meeting");
                        console.log("No request found")
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        
        this.loadActiveMeeting = function(){
            
            this.activeId.style.display = "none"
            this.closeId.style.display = "none";
            this.waitingId.style.display = "none";
            this.speakingId.style.display = "none";    

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/activemeeting";
            //console.log("reqURL: " + reqURL);
            var config = { headers :
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.get(reqURL).then(
                // Success function
                function (response) {
                    console.log("response: " + JSON.stringify(response.data))
                    // assing the part details to the variable in the controller
                    thisCtrl.activeId.style.display = "inherit";
                    console.log("response "+response.data);
                    thisCtrl.meeting = response.data.Meeting[0];

                    //Updating the status of the meeting
                    thisCtrl.activeMeeting = true;
                    thisCtrl.meetingId = response.data.Meeting[0].mID;

                    //Checking if the Senator has made a previous request
                    console.log(typeof($routeParams.uid));
                    thisCtrl.checkRequest();
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        alert("There is no active meeting");
                        thisCtrl.activeId.style.display = "none";
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        
        this.checkActiveMeeting = function(){

            // Now create the url with the route to talk with the rest API
            var reqURL = "https://whitestone.uprm.edu/whitestone/activemeeting";
            //console.log("reqURL: " + reqURL);
            var config = { headers : 
                          {'Content-Type':'application/json;charset=utf-8;' }
                         }
        
            // Now issue the http request to the rest API
            $http.get(reqURL).then(
                // Success function
                function (response) {
                    console.log("response check meeting: " + JSON.stringify(response.data))
                    thisCtrl.checkApproval();
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;

                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("There is no active meeting");
                        console.log("")
                        thisCtrl.activeId.style.display = "none";
                                   //Disabling the buttons to avoid errors
                        thisCtrl.activeId.style.display = "none"
                        thisCtrl.closeId.style.display = "none";
                        thisCtrl.waitingId.style.display = "none";
                        thisCtrl.speakingId.style.display = "none";
                        if(!thisCtrl.clearedInterval){
                            thisCtrl.cancelInterval();
                        }
                        if(thisCtrl.isRecording){
                            //thisCtrl.cancelTurn();
                            thisCtrl.stopRecording();
                        }
                        thisCtrl.activeMeeting = false;
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };

        this.checkRequest = function(){
            var reqURL = "https://whitestone.uprm.edu/whitestone/checkrequest/"+$routeParams.uid;
        
            // Now issue the http request to the rest API
            $http.get(reqURL).then(
                // Success function
                function (response) {
                    console.log("response check request: " + JSON.stringify(response.data))
                    // assing the part details to the variable in the controller	
                     //Resetting data
                    thisCtrl.requestedTurn = true;
                    thisCtrl.closeId.style.display = "inherit";
                    thisCtrl.waitingId.style.display = "inherit";

                    thisCtrl.turnApproved = false;
                    thisCtrl.timedInterval(10000);
                    thisCtrl.checkApproval();
                }, //Error function
                function (response) {
                    // This is the error function
                    // If we get here, some error occurred.
                    // Verify which was the cause and show an alert.
                    var status = response.status;
                    if (status == 0) {
                        alert("No hay conexion a Internet");
                    }
                    else if (status == 401) {
                        alert("Su sesion expiro. Conectese de nuevo.");
                    }
                    else if (status == 403) {
                        alert("No esta autorizado a usar el sistema.");
                    }
                    else if (status == 404) {
                        //alert("There is no active meeting");
                        console.log("No request found")
                    }
                    else if (status == 400) {
                        //alert("There is no active meeting");
                        console.log("Unexpected attributes in post request")
                    }
                    else {
                        alert("Error interno del sistema.");
                    }
                }
            );
        };
        this.loadActiveMeeting();
        
        this.voteRedirect = function(){
            if(!thisCtrl.clearedInterval){
                thisCtrl.cancelInterval();
            }
            if(thisCtrl.isRecording){
                thisCtrl.cancelTurn();
                //thisCtrl.stopRecording();
                //if(thisCtrl.requestedTurn){
                    //thisCtrl.cancelTurn();
                //}
            }
            $location.url('/voting/'+$routeParams.role+'/'+$routeParams.uid);
        }
        this.logout= function(){
            if(thisCtrl.requestedTurn){
                thisCtrl.cancelTurn();
            }
            //if(thisCtrl.isRecording){
            // thisCtrl.stopRecording();
            //}
            authenticationSvc.logoutUser();
            $location.url('/login');
        };
}]);
