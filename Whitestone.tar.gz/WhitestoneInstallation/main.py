#!/usr/bin/python3.5
print("Content-type:text/html\r\n\r\n")

#############################################
# Authors: (CodingGear)                     #
#   Yomaira Rivera Albarran                 #
#   Gustavo Hernandez Ortiz                 #
#   Ariel Torres Perez                      #
#                                           #
# Date: 3/17/2019                           #
# Updated: 5/6/2019                         #
# Distribution: Python 3.5                  #
#                                           #
# Whitestoneis a sound and voting web       #
# application designed for the Academic     #
# Senate of the UPRM                        #
#############################################


from flask_cors import CORS, cross_origin
from flask import Flask, request, render_template, make_response, jsonify
from handler.ActivityLogHandler import ActivityLogHandler
from handler.AudioHandler import AudioHandler
from handler.CredentialHandler import CredentialHandler
from handler.MeetingHandler import MeetingHandler
from handler.UsersHandler import UsersHandler
from handler.VoteInHandler import VoteInHandler
from handler.VotingChoiceHandler import VotingChoiceHandler
from handler.VotingQuestionHandler import VotingQuestionHandler
from handler.RequestsHandler import RequestsHandler
from werkzeug import secure_filename
import os
import radius
#from urllib import parse, request


#print(os.path.abspath(os.path.dirname(__file__)))
#r = radius.Radius('whitestone', host='radius.uprm.edu', port=1812)

app = Flask(__name__ ,template_folder='Whitestone_app')
#app.config['UPLOAD_FOLDER'] = '/audio'
CORS(app)
#@app.route("/")
#def root():
#    return "Hello"

@app.route("/")
def getHtml():
    headers = {'Content-Type': 'text/html'}
    return make_response(render_template('index.html'),200,headers)

# Search list for emergency local access
@app.route('/whitestone/credentials', methods=['GET', 'POST', 'PUT'])
def getAllCredentials():

    if request.method == 'POST':

        print("REQUEST", request.json)
        return CredentialHandler().insertCredentialJSON(request.json)

    if request.method == 'PUT':
        print("REQUEST", request.json)
        return CredentialHandler().updateCredential(request.json)

    else:
        return CredentialHandler().getAllCredentials()



# Search all the user information using its email as identifier
@app.route('/whitestone/credentials/user', methods=['POST'])
def getUser():

    print("Request", request.json)
    return UsersHandler().getUser(request.json)


# Search all the user information using its email as identifier
@app.route('/whitestone/delete/user/<int:uID>', methods=['POST'])
def deleteUser(uID):

    return UsersHandler().deleteUser(uID)


# Search all the info from users registered
@app.route('/whitestone/users', methods=['GET', 'POST'])
def getAllUsers():

    if request.method == 'POST':

        print("REQUEST", request.json)
        return UsersHandler().insertUserJSON(request.json)
    else:

        return UsersHandler().getAllUsersInfo()


# Edit user information
@app.route('/whitestone/edituser/<int:uid>', methods=["PUT"])
def updateUser(uid):
    print("REQUEST", request.json)
    return UsersHandler().updateUser(uid, request.json)


# Search all senators including the chancellor
@app.route('/whitestone/senators', methods=['GET'])
def getAllSenators():
    return UsersHandler().getAllSenator()



# Search all elect senators
@app.route('/whitestone/electsenators', methods=['GET'])
def getAllElectSenators():
    return UsersHandler().getAllElectSenator()


# Search all elect student senators
@app.route('/whitestone/electstudentsenators', methods=['GET'])
def getAllElectStudentSenators():
    return UsersHandler().getAllElectStudentsSenator()


# Search all ex-officio senators
@app.route('/whitestone/exofficiosenators', methods=['GET'])
def getAllExOfficioSenators():
    return UsersHandler().getAllExOfficioSenator()


# Search all Ex-Officio student senators
@app.route('/whitestone/exofficiostudentsenators', methods=['GET'])
def getAllExOfficioStudentSenators():
    return UsersHandler().getAllExOfficioStudentsSenator()


# Search old meetings (inactive)
@app.route('/whitestone/meeting/oldmeetings', methods=['GET'])
def getOldMeetings():
    return MeetingHandler().getOldMeetings()


# Show the active meeting and its info
@app.route('/whitestone/activemeeting', methods=['GET', 'POST'])
def getMeeting():

    if request.method == 'POST':

        print("REQUEST", request.json)
        return MeetingHandler().insertMeetingJSON(request.json)

    else:
        return MeetingHandler().getActiveMeeting()



# Update meeting status
@app.route('/whitestone/meetingstatus', methods=["PUT"])
def updateMeetingStatus():
    print("REQUEST", request.json)
    return MeetingHandler().updateMeetingStatus(request.json)


# Post voting question by mID
@app.route('/whitestone/voting',  methods=['POST'])
def postVotingBymID():
    print("REQUEST", request.json)
    return VotingQuestionHandler().insertVotingJSON(request.json)


# Get inactive or closed voting question by mID
@app.route('/whitestone/inactivevotings/<int:mID>')
def getInactiveVotingBymID(mID):
    return VotingQuestionHandler().getInactiveVotingQuestionBymID(mID)


# Get active or open voting question by mID
@app.route('/whitestone/activevotings/<int:mID>', methods=['GET'])
def getActiveVotingBymID(mID):
    return VotingQuestionHandler().getActiveVotingQuestionBymID(mID)


# Search voting by vID
@app.route('/whitestone/voting/<int:vid>')
def getVotingByvID(vid):
    return VotingQuestionHandler().getVotingQuestionByID(vid)


# Put the voting results by vID
@app.route('/whitestone/votingresults', methods=['PUT'])
def updateVotingResults():
    print("REQUEST", request.json)
    return VotingChoiceHandler().updateVotingChoice(request.json)


# Post voting alternatives
@app.route('/whitestone/voting/choice', methods=['POST'])
def postAlternatives():
    print("REQUEST", request.json)
    return VotingChoiceHandler().insertChoiceJSON(request.json)


# Search voting choices and its altIDs by voting id
@app.route('/whitestone/voting/<int:vid>/choices')
def getAlternatives(vid):
    return VotingChoiceHandler().getVotingChoiceByVID(vid)


# Search active voting choices and its altIDs by voting id
@app.route('/whitestone/activevoting/<int:vid>/choices')
def getActiveVotingAlternatives(vid):
    return VotingChoiceHandler().getActiveVotingChoiceByvID(vid)


#####################TURN METHODS########################
# Update the waiting list
@app.route('/whitestone/requestTurn', methods=['POST'])
def postRequest():
    print("REQUEST SUBMIT", request.json)
    return RequestsHandler().submitRequest(request.json)

# Update the waiting list
@app.route('/whitestone/cancelTurn', methods=['POST'])
def cancelRequest():
    print("REQUEST CANCEL", request.json)
    return RequestsHandler().cancelRequest(request.json)


# Update the waiting list
@app.route('/whitestone/checkrequest/<int:uid>', methods=['GET'])
def checkRequest(uid):
    print("REQUEST CHECK REQUEST")
    return RequestsHandler().checkRequest(uid)

# Update the waiting list
@app.route('/whitestone/checkapproval', methods=['POST'])
def checkApproval():
    print("REQUEST Check Approval ", request.json)
    return RequestsHandler().checkApproval(request.json)

# Update the waiting list
@app.route('/whitestone/emptylist', methods=['POST'])
def clearList():
    return RequestsHandler().clearList()

# Update the waiting list
@app.route('/whitestone/grantrequest', methods=['PUT'])
def grantRequestToSenator():
    print("REQUEST GRANT ", request.json)
    return RequestsHandler().grantRequest(request.json)

# Update the waiting list
@app.route('/whitestone/denyrequest', methods=['PUT'])
def denyRequestToSenator():
    print("REQUEST DENY ", request.json)
    return RequestsHandler().denyRequest(request.json)

# Update the waiting list
@app.route('/whitestone/getrequestlist', methods=['GET'])
def getRequestList():
    print("REQUEST GET LIST ", request.json)
    return RequestsHandler().getRequestList()
#########################################################


# Update voting status to Inactive
@app.route('/whitestone/closevoting', methods=['PUT'])
def closeVoting():
    print("REQUEST", request.json)
    return VotingQuestionHandler().updateVotingStatus(request.json)


# Post or get audio by mID
@app.route('/whitestone/meeting/<int:mid>/audio', methods=['POST', 'GET'])
def meetingAudio(mid):
    if request.method == 'POST':
        print("REQUEST", request.json)
        return AudioHandler().insertAudioJSON(request.json)
    else:
     return AudioHandler().getAudioBymID(mid)



# Get audio by aid
@app.route('/whitestone/audio/<int:aid>', methods=['GET'])
def getAudio(aid):

     return AudioHandler().getAudioByaID(aid)




# Post or get voting participant
@app.route('/whitestone/<int:uid>/votesIn/<int:vid>', methods=['POST', 'GET', 'PUT'])
def VotesIn(vid, uid):
    if request.method == 'POST':
        print("REQUEST", request.json)
        return VoteInHandler().insertVoteInJSON(request.json)

    if request.method == 'PUT':
        print("REQUEST", request.json)
        return VoteInHandler().updateVoteInFlag(request.json)

    else:
        return VoteInHandler().getParticipant(vid, uid)



# Post new activity log
@app.route('/whitestone/activitylog', methods=['POST'])
def ActivityLog():
    print("REQUEST", request.json)
    return ActivityLogHandler().insertActivityLogJSON(request.json)



# Get activity log by date
@app.route('/whitestone/getactivitylog', methods=['POST'])
def getActivityLog():
    print("REQUEST", request.json)
    return ActivityLogHandler().getActivityLogByDate(request.json.get('date'))


# Upload audio files to the server
@app.route('/whitestone/meeting/<int:mid>/upload', methods=['POST'])
def uploadAudio(mid):
    print("UPLOAD FILE")
    if request.method == 'POST':
        #Added by Ariel
        #Creates the folder inside the server
        parentPath = '/var/www/html/Whitestone/static/audio/'
        audioFileFolder = os.path.join(parentPath,str(mid))
        try:
            os.mkdir(audioFileFolder,0o755)
            print("Directory created.")
        except FileExistsError:
            print("Directory exists")
        #Uploads the file to the server
        file = request.files['file']
        file.save(os.path.join(audioFileFolder, secure_filename(file.filename)))
        return("Uploaded: " + audioFileFolder + file.filename)
        #End of added by Ariel
        #file = request.files['file']
        #file.save(os.path.join('/var/www/html/Whitestone/audio', secure_filename(file.filename)))
        #file.save(os.path.join('/var/www/html/Whitestone/static/audio', secure_filename(file.filename)))
        #return "Uploaded file: " + file.filename


@app.route('/radius', methods=['POST'])
def authenticateUser():
	r = radius.Radius('whitestone', host='radius.uprm.edu', port=1812)
	if request.method == 'POST':
		try:
			if r.authenticate(request.json.get('email'), request.json.get('password')):
				return "Success"
			else:
				return "Failure"
		except NameError:
			return "Failure"
		except TypeError:
			return "Failure"
		except:
			return "Failure"


if __name__ == '__main__':
    #app.debug = True
    app.run(ssl_context=('/etc/pki/tls/certs/whitestone.crt', '/etc/pki/tls/certs/whitestone.key'), host='0.0.0.0', port='8000')
        


